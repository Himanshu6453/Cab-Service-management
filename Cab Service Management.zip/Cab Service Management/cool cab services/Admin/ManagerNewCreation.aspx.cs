using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_ManagerNewCreation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            btnBack.Enabled = false;
            if (Request.QueryString["id"] != null)
            {
                GetData();
                Btn_Insert.Text = "Update";
                btnClear.Enabled = false;
                btnBack.Enabled = true;
            }
        }
    }
    private void GetData()
    {
        string Id = Request.QueryString["Id"].ToString();
        AdminBo Data = new AdminBo();

        Data.MangerID = Id;
        DataSet ds = new DataSet();
        ds = Data.SelectMang();
        Txt_EmpName.Text = ds.Tables[0].Rows[0]["EmpName"].ToString();
        Txt_ParmanentAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
        Txt_Qulification.Text = ds.Tables[0].Rows[0]["Qulification"].ToString();
        Txt_DOB.Value= ds.Tables[0].Rows[0]["DOB"].ToString();
        TxtEmailID.Text = ds.Tables[0].Rows[0]["EmailID"].ToString();
        RadioButtonList1.SelectedItem.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
        Txt_PhoneNo.Text = ds.Tables[0].Rows[0]["PhoneNo"].ToString();
        //Txt_Designation.Text = ds.Tables[0].Rows[0]["Designation"].ToString();
        Txt_Designation.ClearSelection();
        Txt_Designation.Items.FindByText(ds.Tables[0].Rows[0]["Designation"].ToString().Trim()).Selected = true;
        //DropDownList1.SelectedItem.Text = ds.Tables[0].Rows[0]["Department"].ToString();
        DropDownList1.ClearSelection();
        DropDownList1.Items.FindByText(ds.Tables[0].Rows[0]["Department"].ToString().Trim()).Selected = true;
        Txt_DOJ.Value = ds.Tables[0].Rows[0]["DOJ"].ToString();

        Txt_Age.Text = ds.Tables[0].Rows[0]["Age"].ToString();

    }
    AdminBo ABO = new AdminBo();
    protected void Btn_Insert_Click(object sender, EventArgs e)
    {
        if (Request.QueryString["id"]==null)
        {
            ABO.ManagerName = Txt_EmpName.Text;
            ABO.PAddress = Txt_ParmanentAddress.Text;
            ABO.Qulification = Txt_Qulification.Text;
            ABO.DOB = Txt_DOB.Value;
            ABO.Gender = RadioButtonList1.SelectedItem.Text;
            ABO.PhoneNo = Txt_PhoneNo.Text;
            ABO.EmailId = TxtEmailID.Text;
            ABO.Department = DropDownList1.SelectedItem.Text;
            ABO.Designation = Txt_Designation.SelectedItem.Text;
            ABO.DOJ = Txt_DOJ.Value;
            ABO.Age = Txt_Age.Text;
            DataSet ds = new DataSet();
            ds = ABO.InsertManagerName();
            if (ds.Tables[0].Rows[0]["MangerID"].ToString().Trim() != "Manager Exists")
            {
                //lblMessage.Text = Txt_EmpName.Text + " Registred Successfully with UserId and Password is :" + ds.Tables[0].Rows[0]["MangerID"].ToString();
                Page.RegisterStartupScript("SS", "<script> alert(' Registred Successfully with UserId and Password is :" + ds.Tables[0].Rows[0]["MangerID"].ToString() + "');</script>");
            }
            else
            {
                //lblMessage.Text = ds.Tables[0].Rows[0]["MangerID"].ToString();
                Page.RegisterStartupScript("SS", "<script> alert('" + ds.Tables[0].Rows[0]["MangerID"].ToString() + "');</script>");
            }
        }
        else if (Request.QueryString["id"] != null)
        {
            ABO.MangerID = Request.QueryString["id"].ToString();
            ABO.ManagerName = Txt_EmpName.Text;
            ABO.PAddress = Txt_ParmanentAddress.Text;
            ABO.Qulification = Txt_Qulification.Text;
            ABO.DOB = Txt_DOB.Value;
            ABO.Gender = RadioButtonList1.SelectedItem.Text;
            ABO.PhoneNo = Txt_PhoneNo.Text;
            ABO.EmailId = TxtEmailID.Text;
            ABO.Department = DropDownList1.SelectedItem.Text;
            ABO.Designation = Txt_Designation.SelectedItem.Text;
            ABO.DOJ = Txt_DOJ.Value;
            ABO.Age = Txt_Age.Text;
            DataSet ds = new DataSet();
            ds = ABO.UpdateManger();
            if (ds.Tables[0].Rows[0]["MangerID"].ToString().Trim() != "Manager Not  Exists")
            {
                Page.RegisterStartupScript("SS", "<script> alert('" + ds.Tables[0].Rows[0]["MangerID"].ToString() + "');</script>");

            }
            else
            {
                Page.RegisterStartupScript("SS", "<script> alert('" + ds.Tables[0].Rows[0]["MangerID"].ToString() + "');</script>");
            }

 
        }
        

        
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Admin/ViewMangerDetails.aspx");
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        try
        {
            foreach (Control ctrl in ((ContentPlaceHolder)Master.FindControl("ContentPlaceHolder1")).Controls)
            {
                if (ctrl.GetType() == typeof(TextBox))
                {
                    ((TextBox)ctrl).Text = string.Empty;
                    Txt_DOB.Value = string.Empty;
                    Txt_DOJ.Value = string.Empty;
                }
                if (ctrl.GetType() == typeof(DropDownList))
                {
                    ((DropDownList)ctrl).SelectedIndex = 0;
                }
            }
        }
        catch
        {
            throw;
        }
    }
}
